import torch as t
import torch.nn as nn
import torchvision as tv
from torch.utils.data import DataLoader
from resnet_model import *
import torchvision.transforms as transforms
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import label_binarize
from sklearn.metrics import roc_curve, auc
from itertools import cycle
import torch.optim as optim
import matplotlib.pyplot as plt
from scipy import interp
import itertools
import openpyxl
import numpy as np
import torch
import os
import glob
import time
from datetime import datetime
from PIL import Image
from tensorboardX import SummaryWriter
from torch.utils.data import Dataset
import _pickle as pickle
from Videodataset import VideoDataset
import seaborn as sn


def image_border(src, dst,label, width):
    img_ori = Image.open(src)
    fullpath = src.replace('seg','full')
    full_ori = Image.open(fullpath)
    full_ori = full_ori.resize((256,256))
    w = img_ori.size[0]
    h = img_ori.size[1]
    color = (0, 0, 0)
    if (label == 0):
        color = (0, 255, 0)
    elif (label == 1):
        color = (255, 255, 0)
    elif (label == 2):
        color = (255, 180, 90)
    elif (label == 3):
        color = (255, 0, 0)

    w += 2 * width
    h += 2 * width
    img_new = Image.new('RGB', (w, h), color)
    img_new.paste(img_ori, (width, width))
    full_new = Image.new('RGB', (w, h), color)
    full_new.paste(full_ori, (width, width))

    img_new.save(dst)
    fsave = dst.replace('png', 'jpg')
    full_new.save(fsave)


os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"
def vedio_classification(checkpoint_path):
    workbook = openpyxl.Workbook()

    sheet = workbook.active
    dataexcel=[]

    norm_mean = [0.485, 0.456, 0.406]
    norm_std = [0.229, 0.224, 0.225]
    n_classes = 4
    test_transform = transforms.Compose([
        transforms.Resize((256,256)),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(norm_mean, norm_std),
    ])
    acc = 0.0
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    net = resnet101(pretrained=False)
    num_ftrs = net.fc.in_features
    net.fc = nn.Linear(num_ftrs, 4)
    net.fc = nn.Sequential(
        nn.Linear(num_ftrs, 256),
        nn.ReLU(),
        nn.Dropout(1),
        nn.Linear(256, 4)
    )
    if torch.cuda.device_count() > 1:
        net = nn.DataParallel(net, device_ids=[0, 1])
    # net.load_state_dict(torch.load('results/02-08_10-27--attention--81%--video--90%/checkpoint_best.pkl', map_location=device)["model_state_dict"])
    net.load_state_dict(torch.load(open(checkpoint_path, 'rb'), map_location=device)["model_state_dict"])
    criterion = nn.CrossEntropyLoss()
    net.to(device)
    net.eval()
    data_path = r'E:\ggg\ULSAM_Resnetequal\dataset937'
    dir_list = os.listdir(data_path)
    y_true = []
    y_pred = []
    y_predtensor = []
    zhen_number = []
    for dbtype in dir_list[::]:
        list = os.listdir(data_path + '\\' + dbtype)
        print('路径：',list)
        for type in list[::]:
            loader_time = time.time()
            path = data_path + '\\' + dbtype + '\\' + type
            ground_truth = {'label':None,'value':0}
            if path.find('none') != -1:
                ground_truth['label']='none'
                ground_truth['value']=0
            elif path.find('few') != -1:
                ground_truth['label'] = 'few'
                ground_truth['value'] = 1
            elif path.find('mid') != -1:
                ground_truth['label'] = 'mid'
                ground_truth['value'] = 2
            elif path.find('max') != -1:
                ground_truth['label'] = 'large'
                ground_truth['value'] = 3
            elif path.find('large') != -1:
                ground_truth['label'] = 'large'
                ground_truth['value'] = 3
            y_true.append(ground_truth['value'])
            out_list = []
            out_img = []
            y_predallclass = []
            data_dir = glob.glob(data_path + '\\' + dbtype + '\\' + type + '/*.jpg')
            test_dataset = VideoDataset(data_dir=data_dir, mode="test", transform=test_transform)
            test_dataloader = DataLoader(dataset=test_dataset, batch_size=36, num_workers=0 ,shuffle=False)
            start_time = time.time()
            with torch.no_grad():
                for data in test_dataloader:
                    path_img, imgs = data
                    img = imgs.to(device)
                    output = net(img)
                    output_mask = output.cpu().data.numpy().copy()
                    output_mask = np.argmax(output_mask, axis=1)
                    for i in range(len(path_img)):
                        predict = torch.softmax(torch.squeeze(output[i]).cpu(), dim=0)
                        y_predallclass.append(predict.numpy())
                        out_list.append(output_mask[i])
                        out_img.append(path_img[i])

            y_predtensor.append(y_predallclass)
            out_dict = {0:0,1:0,2:0,3:0}
            maxcount = {0:0,1:0,2:0,3:0}
            count = 1
            for index in range(0, len(out_list)):
                if index  == (len(out_list) - 1):
                    if count >= maxcount[out_list[index]]:
                        out_dict[out_list[index]] = count
                        out_dict['index{}'.format(out_list[index])] = index
                        maxcount[out_list[index]] = out_dict[out_list[index]]
                        break
                    else:
                        break

                elif out_list[index] == out_list[index + 1]:
                    count += 1
                elif count >= maxcount[out_list[index]]:
                    out_dict[out_list[index]] = count
                    out_dict['index{}'.format(out_list[index])] = index
                    maxcount[out_list[index]] = out_dict[out_list[index]]
                    count = 1
                else:
                    count = 1

            print(out_dict)
            errorvaule = round(len(data_dir) / 100)
            output = {'label':None,'value': -1}

            if(3 in out_dict.keys() and out_dict[3]>=2):
                output = {'label': 'large', 'value': 3}
            elif(2 in out_dict.keys() and out_dict[2]>=1):
                output = {'label': 'mid', 'value': 2}
            elif (1 in out_dict.keys() and out_dict[1]>=1):
                output = {'label': 'few', 'value': 1}
            elif (0 in out_dict.keys() and out_dict[0]>=1):
                output = {'label': 'none', 'value': 0}
            y_pred.append(output['value'])
            end_time = time.time()
            print(start_time - loader_time,end_time - start_time,end_time - loader_time)
            print('vedio_pred：{}    min_frames：{}     total_frames：{}    lodertime:{:.3f}   time:{:.3f}'.format(output['label'],errorvaule,len(out_img),start_time-loader_time, end_time-loader_time))


            out_zhen = round(out_dict['index{}'.format(output['value'])]-out_dict[output['value']]/2)
            print(out_img[out_zhen])
            print()
            if(ground_truth['value'] == output['value']):
                acc += 1

            list_val=[]
            true_video=ground_truth['value']
            pred_video=output['value']
            key_frame=out_img[out_zhen]
            video_name =os.path.basename(key_frame).split("-")[0]
            list_val.append(video_name)
            list_val.append(true_video)
            list_val.append(pred_video)
            list_val.append(key_frame)
            dataexcel.append(list_val)

    for row_data in dataexcel:
        sheet.append(row_data)

    workbook.save("example.xlsx")

    # 关闭工作簿
    workbook.close()
    cnf_matrix = confusion_matrix(y_true, y_pred)
    print(cnf_matrix)
    FP = cnf_matrix.sum(axis=0) - np.diag(cnf_matrix)
    FN = cnf_matrix.sum(axis=1) - np.diag(cnf_matrix)
    TP = np.diag(cnf_matrix)
    TN = cnf_matrix.sum() - (FP + FN + TP)

    FP = FP.astype(float)
    FN = FN.astype(float)
    TP = TP.astype(float)
    TN = TN.astype(float)
    # Precision or positive predictive value
    PPV = TP / (TP + FP)
    # Overall accuracy
    ACC = (TP + TN) / (TP + FP + FN + TN)
    # Specificity (SPC):
    SPC = TN / (TN + FP)
    # Recall (REC) or Sensitivity or True Positive Rate (TPR):
    REC = TP / (TP + FN)
    num_classes = len(cnf_matrix)
    for i in range(num_classes):
        print(f"class {i} - PPV: {PPV[i]}, ACC: {ACC[i]}, SPC: {SPC[i]}, REC: {REC[i]}")

    print("PPV：", PPV.mean(), "ACC：", ACC.mean(), "SPC:", SPC.mean(), "REC:", REC.mean())
    # sn.heatmap(cnf_matrix, annot=True, cmap='Purples')
    # print(cnf_matrix)
    # FP = cnf_matrix.sum(axis=0) - np.diag(cnf_matrix)
    # FN = cnf_matrix.sum(axis=1) - np.diag(cnf_matrix)
    # TP = np.diag(cnf_matrix)
    # TN = cnf_matrix.sum() - (FP + FN + TP)
    #
    # FP = FP.astype(float)
    # FN = FN.astype(float)
    # TP = TP.astype(float)
    # TN = TN.astype(float)
    #
    # # Sensitivity, hit rate, recall, or true positive rate
    # TPR = TP / (TP + FN)
    # # Precision or positive predictive value
    # PPV = TP / (TP + FP)
    # # Fall out or false positive rate
    # FPR = FP / (FP + TN)
    # # Overall accuracy
    # ACC = (TP + TN) / (TP + FP + FN + TN)
    # # F1
    # F1 = 2 * PPV * TPR / (PPV + TPR)
    #
    # print('TPR：', TPR)
    # print('PPV：', PPV)
    # print('FPR：', FPR)
    # print('ACC:', ACC)
    # print('F1：', F1)
    # print()
    # print('------------------AVG-----------------')
    # print('TPR：{:.2%}    TPR：{:.2%}   FPR：{:.2%}  ACC：{:.2%}   F1：{:.2%}'.format(TPR.mean(),
    #                                                                              PPV.mean(), FPR.mean(),ACC.mean(), F1.mean()))
    # y_score = np.zeros(shape=(20, n_classes))
    # y = label_binarize(y_true, classes=[0, 1, 2, 3])
    # for i in range(937):
    #     y_score[i:] = y_predtensor[i][zhen_number[i]]
    #
    # fpr = dict()
    # tpr = dict()
    # roc_auc = dict()
    # for i in range(n_classes):
    #     fpr[i], tpr[i], _ = roc_curve(y[:, i], y_score[:, i])
    #     roc_auc[i] = auc(fpr[i], tpr[i])
    #
    # # Compute macro-average ROC curve and ROC area
    # # First aggregate all false positive rates
    # all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    # # Then interpolate all ROC curves at this points
    # mean_tpr = np.zeros_like(all_fpr)
    # for i in range(n_classes):
    #     mean_tpr += interp(all_fpr, fpr[i], tpr[i])
    # # Finally average it and compute AUC
    # mean_tpr /= n_classes
    # fpr["macro"] = all_fpr
    # tpr["macro"] = mean_tpr
    # roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])
    #
    # # Plot all ROC curves
    # lw = 2
    # plt.figure()
    # plt.plot(fpr["macro"], tpr["macro"],
    #          label='macro-average ROC curve (area = {0:0.3f})'
    #                ''.format(roc_auc["macro"]),
    #          color='navy', linestyle=':', linewidth=4)
    #
    # colors = cycle(['yellow', 'aqua', 'darkorange', 'cornflowerblue'])
    # for i, color in zip(range(n_classes), colors):
    #     plt.plot(fpr[i], tpr[i], color=color, lw=lw,
    #              label='ROC curve of class {0} (area = {1:0.3f})'
    #                    ''.format(i, roc_auc[i]))
    #
    # plt.plot([0, 1], [0, 1], 'k--', lw=lw)
    # plt.xlim([0.0, 1.0])
    # plt.ylim([0.0, 1.05])
    # plt.xlabel('False Positive Rate')
    # plt.ylabel('True Positive Rate')
    # plt.title('ROC Curve For Diagnosis of PFO')
    # plt.legend(loc="lower right")
    # plt.show()

if __name__ == "__main__":
    norm_mean = [0.485, 0.456, 0.406]
    norm_std = [0.229, 0.224, 0.225]
    path_checkpoint = r'.\results/date/checkpoint_best.pkl'
    vedio_classification(path_checkpoint)
