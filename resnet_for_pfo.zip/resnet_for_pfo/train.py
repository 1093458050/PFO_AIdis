import torch as t
import torch.nn as nn
import torchvision as tv
from torch.utils.data import DataLoader
import torchvision.transforms as transforms
import torch.optim as optim
import numpy as np
import torch
import os
from test import test_classification
from resnet_model import *
from datetime import datetime
from PIL import Image
from tensorboardX import SummaryWriter
from torch.utils.data import Dataset
from Mydataset import ExpressionDataset
from testVideo import *

os.environ["CUDA_DEVICES_ORDER"]="PCI_BUS_IS"

os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"

if __name__ == "__main__":
    tv.models
    now_time = datetime.now()
    time_str = datetime.strftime(now_time, '%m-%d_%H-%M')
    print(time_str)
    data_dir = r'./data/image/train'
    valid_dir = data_dir.replace('train','val')
    BASE_DIR = os.path.dirname(os.path.join(__file__))
    log_dir = os.path.join(BASE_DIR,"results",time_str)
    path_checkpoint = ''
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    #
    MAX_EPOCH = 60
    BATCH_SIZE = 100
    lr = 0.001
    milestones = [10,20,30,40]
    log_interval = 1
    val_interval = 1
    start_epoch = 0
    lr_decay_step = 40
    writer = SummaryWriter()

    norm_mean = [0.485, 0.456, 0.406]
    norm_std = [0.229, 0.224, 0.225]

    train_transform = transforms.Compose([
        transforms.Resize((256,256)),
        transforms.CenterCrop(224),
        # transforms.RandomCrop(200),
        # transforms.RandomHorizontalFlip(),
        # transforms.RandomRotation((-30, 30)),
        transforms.ToTensor(),
        transforms.Normalize(norm_mean, norm_std),
    ])

    valid_transform = transforms.Compose([
        transforms.Resize((256,256)),
        transforms.CenterCrop(224),
        # transforms.RandomCrop(200),
        transforms.ToTensor(),
        transforms.Normalize(norm_mean, norm_std),
    ])

    train_dataset = ExpressionDataset(data_dir=data_dir, mode="train", transform=train_transform)
    valid_dataset = ExpressionDataset(data_dir=valid_dir, mode="valid", transform=valid_transform)
    train_size = len(train_dataset)
    valid_size = len(valid_dataset)

    train_dataloader = DataLoader(dataset=train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
    valid_dataloader = DataLoader(dataset=valid_dataset, batch_size=BATCH_SIZE,shuffle=True,  num_workers=0)

    net = resnet101(pretrained=False)
    model_dict = net.state_dict()

    pretrained_dict = torch.load('resnet101-63fe2227.pth')
    pretrained_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict}
    model_dict.update(pretrained_dict)
    net.load_state_dict(model_dict)
    num_ftrs = net.fc.in_features
    net.fc = nn.Linear(num_ftrs, 4)
    net.fc = nn.Sequential(
        nn.Linear(num_ftrs, 256),
        nn.ReLU(),
        nn.Dropout(0.5),
        nn.Linear(256, 4)
    )

    if torch.cuda.device_count() > 1:
        net = nn.DataParallel(net, device_ids=[0, 1])

    criterion = nn.CrossEntropyLoss()

    optimizer = optim.SGD(net.parameters(), lr=lr, momentum=0.9,weight_decay=1e-4)
    scheduler = optim.lr_scheduler.MultiStepLR(optimizer, gamma=0.2, milestones=milestones)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    if not os.path.exists('checkpoints'):
        os.mkdir('checkpoints')
    best_acc = 0.0
    for epoch in range(start_epoch+1, MAX_EPOCH + 1):
        running_train_loss = 0.0
        running_train_accs = 0.0
        net.train()
        for data in train_dataloader:
            path_img, imgs, labels = data
            img, label = imgs.to(device).float(), labels.to(device).float()
            net.to(device)
            output = net(img)
            train_loss = criterion(output, label.long())
            output_mask = output.cpu().data.numpy().copy()
            output_mask = np.argmax(output_mask, axis=1)
            y_mask = label.cpu().data.numpy().copy()
            train_acc = (output_mask == y_mask).sum()

            optimizer.zero_grad()
            train_loss.backward()
            optimizer.step()
            running_train_loss += (train_loss.data.item())
            running_train_accs += train_acc
        scheduler.step()
        epoch_train_loss = running_train_loss / train_size
        epoch_train_acc = running_train_accs / train_size
        running_test_loss = 0.0
        running_test_accs = 0.0
        net.eval()
        with torch.no_grad():
            for data in valid_dataloader:
                path_img, imgs, labels = data
                img, label = imgs.to(device).float(), labels.to(device).float()
                output = net(img)
                valid_loss = criterion(output, label.long())
                output_mask = output.cpu().data.numpy().copy()
                output_mask = np.argmax(output_mask, axis=1)
                y_mask = label.cpu().data.numpy().copy()
                val_acc = (output_mask == y_mask).sum()
                running_test_loss += valid_loss.data.item()
                running_test_accs += val_acc

            epoch_valid_loss = running_test_loss / valid_size
            epoch_valid_acc = running_test_accs / valid_size
            if best_acc < epoch_valid_acc or best_acc == epoch_valid_acc:
                best_acc = epoch_valid_acc
                best_epoch = epoch
                checkpoint = {"model_state_dict": net.state_dict(),
                              "optimizer_state_dict": optimizer.state_dict(),
                              "epoch": epoch,
                              "best_acc": best_acc}
                path_checkpoint = os.path.join(log_dir, "checkpoint_best.pkl")
                torch.save(checkpoint, path_checkpoint)

        writer.add_scalar('data/trainloss', epoch_train_loss, epoch)
        writer.add_scalar('data/trainacc', epoch_train_acc, epoch)
        writer.add_scalar('data/valloss', epoch_valid_loss, epoch)
        writer.add_scalar('data/valacc', epoch_valid_acc, epoch)
        print("Epoch[{:0>3}/{:0>3}] Train Acc: {:.2%} Valid Acc:{:.2%} Train loss:{:.4f} Valid loss:{:.4f} LR:{}"
              .format(epoch, MAX_EPOCH, epoch_train_acc, epoch_valid_acc, epoch_train_loss, epoch_valid_loss,
                      optimizer.param_groups[0]["lr"]))

    writer.export_scalars_to_json("./all_scalars.json")
    writer.close()
    print(" done ~~~~ {}, best acc: {} in :{} epochs. ".format(datetime.strftime(datetime.now(), '%m-%d_%H-%M'),
                                                               best_acc,best_epoch))
    test_classification(test_dir, norm_mean, norm_std, path_checkpoint)
    vedio_classification(path_checkpoint)

