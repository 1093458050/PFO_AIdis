import cv2
import torch as t
import torch.nn as nn
import torchvision as tv
from torch.utils.data import DataLoader
import torchvision.transforms as transforms
import torch.optim as optim
import numpy as np
import torch
import os
import glob
import random
import time
from datetime import datetime
from PIL import Image
from tensorboardX import SummaryWriter
from torch.utils.data import Dataset
# import matplotlib
random.seed(1)

class VideoDataset(Dataset):
    def __init__(self, data_dir, mode="train", split_n=0.8, rng_seed=620, transform=None):
        #
        self.mode = mode
        self.data_dir = data_dir
        self.rng_seed = rng_seed
        self.split_n = split_n
        self.data_info = self._get_img_info(data_dir)
        self.transform = transform

    def __getitem__(self, index):
        path_img = self.data_info[index]
        img = Image.open(path_img).convert('RGB')
        if self.transform is not None:
            img = self.transform(img)
        return path_img, img

    def __len__(self):
        if len(self.data_info) == 0:
            raise Exception("\ndata_dir:{} is a empty dir! Please checkout your path to images!".format(self.data_dir))
        return len(self.data_info)

    def _get_img_info(self,path):
        image_path_list = []
        for image_path in path:
            image_path_list.append(image_path)
        return image_path_list

def def_label(path):
    dest1 = 'few'  # label --> 0
    dest2 = 'large'  # 1
    dest3 = 'max'  # 1
    dest4 = 'mid'   # 2
    dest5 = 'none'  # 3
    label = 0
    if path.find(dest1) != -1:
        label = 0
    elif path.find(dest2) != -1:
        label = 1
    elif path.find(dest3) != -1:
        label = 1
    elif path.find(dest4) != -1:
        label = 2
    elif path.find(dest5) != -1:
        label = 3
    return label

if __name__ == "__main__":
    import os
    path_dir = r'./data/segemention/train'
    # dset = ExpressionDataset(data_dir=path_dir, mode="train", transform=None)