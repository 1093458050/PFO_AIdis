import torch.nn as nn
from resnet_model import *
from torch.utils.data import DataLoader
import torchvision.transforms as transforms
import torchvision as tv
import numpy as np
from sklearn.preprocessing import label_binarize
import torch
from sklearn.metrics import roc_curve, auc
import os
from datetime import datetime
from PIL import Image
from tensorboardX import SummaryWriter
from torch.utils.data import Dataset
from sklearn.metrics import confusion_matrix
# import pyupset as pyu
from pickle import load
import os
import numpy as np
import matplotlib.pyplot as plt
from itertools import cycle
from sklearn import svm, datasets
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import label_binarize
from sklearn.multiclass import OneVsRestClassifier
from scipy import interpolate
from scipy import interp
from facalloss import *
import seaborn as sn
from Mydataset import ExpressionDataset


def image_border(src, dst,label, width):

    img_ori = Image.open(src)
    img_ori = img_ori.resize((256, 256), Image.ANTIALIAS)
    fullcolor = src.replace('test', 'ori')
    full = Image.open(fullcolor)
    full = full.resize((256, 256), Image.ANTIALIAS)
    w = img_ori.size[0]
    h = img_ori.size[1]
    color = (0, 0, 0)
    if (label == 0):
        color = (0, 255, 0)
    elif (label == 1):
        color = (255, 255, 0)
    elif (label == 2):
        color = (255, 180, 90)
    elif (label == 3):
        color = (255, 0, 0)

    w += 2 * width
    h += 2 * width
    img_new = Image.new('RGB', (w, h), color)
    img_new.paste(img_ori, (width, width))

    full_new = Image.new('RGB', (w, h), color)
    full_new.paste(full, (width, width))
    img_new.save(dst.replace('test','addcolor'))
    full_new.save(fullcolor.replace('ori','addcolor'))

# if __name__ == "__main__":
def test_classification(data_dir,norm_mean,norm_std,checkpoint_path):

    data_dir = data_dir
    norm_mean = norm_mean
    norm_std = norm_std
    n_classes = 4
    test_transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        # transforms.RandomCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(norm_mean, norm_std),
    ])
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    test_dataset = ExpressionDataset(data_dir=data_dir, mode="test", transform=test_transform)
    criterion = nn.CrossEntropyLoss()
    test_dataloader = DataLoader(dataset=test_dataset, batch_size=36, num_workers=0,shuffle=True,generator=torch.Generator(device='cuda'))
    test_size = len(test_dataset)

    # net = tv.models.vgg16(pretrained=False)
    # net.fc = nn.Sequential(
    #     nn.Linear(in_features=25088, out_features=4096, bias=True),
    #     nn.ReLU(inplace=True),
    #     nn.Dropout(0.5, inplace=False),
    #     nn.Linear(in_features=4096, out_features=4096, bias=True),
    #     nn.ReLU(inplace=True),
    #     nn.Dropout(0.5, inplace=False),
    #     nn.Linear(in_features=4096, out_features=4, bias=True)
    # )

    net = resnet101(pretrained=False)
    # net = resnet34(pretrained=False)
    # net = resnet50(pretrained=False)
    num_ftrs = net.fc.in_features
    net.fc = nn.Linear(num_ftrs, n_classes)
    net.fc = nn.Sequential(
        nn.Linear(num_ftrs, 256),
        nn.ReLU(),
        nn.Dropout(1),
        nn.Linear(256, 4)
    )
    if torch.cuda.device_count() > 1:
        net = nn.DataParallel(net, device_ids=[0, 1])
    fr = open(checkpoint_path, 'rb')
    data = torch.load(fr,map_location='cpu')
    net.load_state_dict(data['model_state_dict'])
    net.to(device)
    net.eval()
    y_true = []
    y_pred = []
    y_predallclass = []
    path = []
    running_test_loss = 0.0
    with torch.no_grad():
        test_acc = 0
        for data in test_dataloader:
            path_img,imgs, labels = data
            img, label = imgs.to(device), labels.to(device)
            output = net(img)
            test_loss = criterion(output, label.long())
            running_test_loss += test_loss.data.item()
            output_mask = output.cpu().data.numpy().copy()
            output_mask = np.argmax(output_mask, axis=1)
            y_mask = label.cpu().data.numpy().copy()
            for i in range(len(output_mask)):
                predict = torch.softmax(torch.squeeze(output[i]).cpu(), dim=0)
                y_predallclass.append(predict.numpy())
                # predict_cla = torch.argmax(predict).numpy()
                # print_res = predict[predict_cla].numpy()
                # print('path_img:',path_img[i],'   y_mask:',y_mask[i],'  output_mask:',output_mask[i])
                path.append(path_img[i])
                y_true.append(y_mask[i])
                y_pred.append(output_mask[i])

            test_acc = test_acc +  (output_mask == y_mask).sum()

        epoch_test_acc = test_acc / test_size
        epoch_test_loss = running_test_loss / test_size
        cnf_matrix = confusion_matrix(y_true, y_pred)
        sn.heatmap(cnf_matrix,fmt='g',annot=True,cmap='Purples')
        print(cnf_matrix)
        FP = cnf_matrix.sum(axis=0) - np.diag(cnf_matrix)
        FN = cnf_matrix.sum(axis=1) - np.diag(cnf_matrix)
        TP = np.diag(cnf_matrix)
        TN = cnf_matrix.sum() - (FP + FN + TP)

        FP = FP.astype(float)
        FN = FN.astype(float)
        TP = TP.astype(float)
        TN = TN.astype(float)

        # Sensitivity, hit rate, recall, or true positive rate
        TPR = TP / (TP + FN)
        # Precision or positive predictive value
        PPV = TP / (TP + FP)
        # Fall out or false positive rate
        # FPR = FP / (FP + TN)
        # Overall accuracy
        ACC = (TP + TN) / (TP + FP + FN + TN)
        #F1值
        F1 = 2 * PPV * TPR / (PPV + TPR)
        # # Specificity or true negative rate
        TNR = TN / (TN + FP)
        # # False negative rate
        # FNR = FN / (TP + FN)
        # # Negative predictive value
        # NPV = TN / (TN + FN)
        # # False discovery rate
        # FDR = FP / (TP + FP)
        print('TPR：', TPR)
        print('PPV：', PPV)
        print('FPR：', FPR)
        print('ACC:', ACC)
        print('F1：', F1)
        print()
        print('------------------AVG-----------------')
        print('TPR：{:.2%}    TPR：{:.2%}   FPR：{:.2%}  ACC：{:.2%}   F1：{:.2%}'.format(TPR.mean(),
                                                                                     PPV.mean(), FPR.mean(),ACC.mean(), F1.mean()))

    print('Test Acc:{:.2%}'.format(epoch_test_acc))
    print('Test Loss:{:.2%}'.format(epoch_test_loss))

        # for i in range(len(y_pred)):
    #     dst_path = path[i].replace('jpg','png')
    #     image_border(path[i],dst_path, y_pred[i], width=10)


    y_score = np.zeros(shape=(len(y_predallclass), n_classes))
    for i in range(len(y_predallclass)):
        y_score[i:] = y_predallclass[i]
    y = label_binarize(y_true, classes=[0, 1, 2, 3])

    fpr = dict()
    tpr = dict()
    yu = dict()
    roc_auc = dict()
    for i in range(n_classes):
        fpr[i], tpr[i], yu[i] = roc_curve(y[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
    # Compute micro-average ROC curve and ROC area
    # fpr["micro"], tpr["micro"], _ = roc_curve(y.ravel(), y_score.ravel())
    # roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])

    # Compute macro-average ROC curve and ROC area
    # First aggregate all false positive rates
    all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    # Then interpolate all ROC curves at this points
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        mean_tpr += interp(all_fpr, fpr[i], tpr[i])
    # Finally average it and compute AUC
    mean_tpr /= n_classes
    fpr["macro"] = all_fpr
    tpr["macro"] = mean_tpr
    roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])

    # Plot all ROC curves
    lw = 2
    plt.figure()
    # plt.plot(fpr["micro"], tpr["micro"],
    #          label='micro-average ROC curve (area = {0:0.3f})'
    #                ''.format(roc_auc["micro"]),
    #          color='deeppink', linestyle=':', linewidth=4)

    # oldversion
    # plt.plot(fpr["macro"], tpr["macro"],
    #          label='macro-average ROC curve (area = {0:0.3f})'
    #                ''.format(roc_auc["macro"]),
    #          color='navy', linestyle=':', linewidth=4)
    # newversion
    plt.plot(fpr["macro"], tpr["macro"],
             label='Average, AUC = {0:0.3f}'
                   ''.format(roc_auc["macro"]),
             color='navy', linestyle=':', linewidth=4)

    colors = cycle(['yellow', 'aqua', 'darkorange', 'cornflowerblue'])
    for i, color in zip(range(n_classes), colors):
        plt.plot(fpr[i], tpr[i], color=color, lw=lw,
                 label='Grade {0},AUC = {1:0.3f}'
                       ''.format(i, roc_auc[i]))

    plt.plot([0, 1], [0, 1], 'k--', lw=lw)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curve for Grade Classification of PFO')
    plt.legend(loc="lower right")
    plt.show()


# if __name__ == "__main__":
#     norm_mean = [0.485, 0.456, 0.406]
#     norm_std = [0.229, 0.224, 0.225]
#     path_checkpoint = r'.\results/checkpoint.pkl'
#     test_classification(r'./data/test', norm_mean, norm_std, path_checkpoint)
