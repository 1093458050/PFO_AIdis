import torch
import cv2
import os
import glob
import torchvision as tv
import numpy as np
from PIL import Image
from torch.utils.data import Dataset
import random

L = 600
W = 800
class ISBI_Loader(Dataset):
    def __init__(self, data_path,transform):
        self.imgs_path = data_path
        self.transform = transform


    def __getitem__(self, index):
        image_path = self.imgs_path[index]
        label_path = image_path.replace('image', 'label')

        image = Image.open(image_path)
        image = image.resize((256, 256))
        label = cv2.imread(label_path)
        label = cv2.resize(label, (256, 256))
        label = cv2.cvtColor(label, cv2.COLOR_BGR2GRAY)
        label = label.reshape(1, label.shape[0], label.shape[1])


        if label.max() > 1:
            label = label / 255
        if self.transform is not None:
            image = self.transform(image)
        return image, label



    def __len__(self):
        # 返回训练集大小
        return len(self.imgs_path)

if __name__ == "__main__":
    path = 'F:/pycharm/OU-Net/data/train'
    isbi_dataset = ISBI_Loader(path)
    print("数据个数：", len(isbi_dataset))
    train_loader = torch.utils.data.DataLoader(dataset=isbi_dataset,
                                               batch_size=2,
                                               shuffle=True)
    for image, label in train_loader:
        print(image.shape,label.shape)

class normalize():
    def normalize_image(image):
        mean = 0.149
        var = 0.191
        image = (image - mean) / np.sqrt(var)
        return image