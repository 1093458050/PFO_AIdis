
import os
from random import random
import glob
import random as ran
import cv2
import numpy as np
data_dir = r'F:\Firefox Downloding\paper\U-Net1\data'

def _get_img_info(rng_seed,split_n,mode):
    image_path_list = []
    label_path_list = []

    image_path_list = glob.glob(os.path.join(data_dir,'src\*.bmp'))
    label_path_list = glob.glob(os.path.join(data_dir,'label\*.bmp'))

    data_info = [[n,l] for n,l in zip(image_path_list,label_path_list)] #将图片路径-标签 关联起来

    ran.seed(rng_seed)
    ran.shuffle(data_info) #将列表元素打乱
    split_idx = int(len(data_info) * split_n)
    train_len = data_info[:split_idx]
    val_len = data_info[split_idx:]
    print(len(train_len),len(val_len))

    with open('../data/train.txt', 'w', encoding='utf-8') as ftrain,open('../data/val.txt','w') as fval:
        for i in train_len:
            ftrain.write(i[0] + ' ' + i[1] + '\n')
        ftrain.close()
        for i in val_len:
            fval.write(i[0] + ' ' + i[1] + '\n')
        fval.close()
def change_mask(datapath):
    label_path_list = glob.glob(os.path.join(data_dir, 'label\*.bmp'))
    for i in label_path_list:
        img = cv2.imread(i)
        mask = (img / 255).astype(np.uint8)
        cv2.imwrite(i,mask)
        # cv2.remove()
        # cv2.imshow('aws',mask)
        # cv2.waitKey()
        # cv2.destroyAllWindows()
    # img = cv2.imread(datapath)

    #

if __name__ == '__main__':
    _get_img_info(1,0.9,'train')
#     datapath = r'F:\Firefox Downloding\paper\test(Origin U-Net predict result)\271_res.bmp'
#     change_mask(datapath)