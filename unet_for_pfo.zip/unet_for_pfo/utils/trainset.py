import torch
import cv2
import os
import glob
from torch.utils.data import Dataset
import random

L = 600
W = 800
class ISBI_Loader(Dataset):
    def __init__(self, data_path):
        # 初始化函数，读取所有data_path下的图片
        self.data_path = data_path
        self.imgs_path = glob.glob(os.path.join(data_path, 'image/*.jpg'))
        for i in range(len(self.imgs_path)):
            # 根据index读取图片
            image_path = self.imgs_path[i]
            # 根据image_path生成label_path
            label_path = image_path.replace('image', 'label')
            # 读取训练图片和标签图片
            image = cv2.imread(image_path)
            label = cv2.imread(label_path)
            if image.shape[1] != 800 or label.shape[1] != 800:
                print(image.shape[0])
                print(image.shape[1])
                wt = (image.shape[0] - 600)/2
                he = (image.shape[1] - 800)/2
                if image.shape[1] != 800:
                    image = image[wt:image.shape[0] - wt, he:image.shape[1] - he]  # h*w  高*长
                if label.shape[1] != 800:
                    label = label[wt:image.shape[0] - wt, he:image.shape[1] - he]  # h*w  高*长
                # print(image.shape,label.shape)
                cv2.imwrite(image_path, image)
                cv2.imwrite(label_path,label)
                # print(image_path,label_path)

    def __getitem__(self, index):
        # 根据index读取图片
        image_path = self.imgs_path[index]
        # 根据image_path生成label_path
        label_path = image_path.replace('image', 'label')
        # 读取训练图片和标签图片
        image = cv2.imread(image_path)
        label = cv2.imread(label_path)
        # print(image.shape)
        # 将数据转为单通道的图片
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        label = cv2.cvtColor(label, cv2.COLOR_BGR2GRAY)
        image = image.reshape(1, L, W)
        label = label.reshape(1, L, W)
        # print('88888--{}'.format(image.shape))
        # 处理标签，将像素值为255的改为1
        if label.max() > 1:
            label = label / 255
        # 随机进行数据增强，为2时不做处理
        # flipCode = random.choice([-1, 0, 1, 2])
        # if flipCode != 2:
        #     image = self.augment(image, flipCode)
        #     label = self.augment(label, flipCode)
        return image, label

    def __len__(self):
        # 返回训练集大小
        return len(self.imgs_path)

if __name__ == "__main__":
    path = '../data/train'
    isbi_dataset = ISBI_Loader(path)
    print("数据个数：", len(isbi_dataset))
    train_loader = torch.utils.data.DataLoader(dataset=isbi_dataset,
                                               batch_size=2,
                                               shuffle=True)
    for image, label in train_loader:
        print(image.shape,label.shape)


    # imgs_path = glob.glob(os.path.join(path, '*.jpg'))
    # for i in range(len(imgs_path)):
    #     print(i)
    #     # 根据index读取图片
    #     image_path = imgs_path[i]
    #     # 读取训练图片和标签图片
    #     image = cv2.imread(image_path)
    #     if image.shape[1] != 800:
    #         image = image[84:684, 112:912]  # h*w  高*长
    #         # print(image.shape,label.shape)
    #         cv2.imwrite(image_path, image)
    #         # print(image_path,label_path)
    #     # print(image.shape)
