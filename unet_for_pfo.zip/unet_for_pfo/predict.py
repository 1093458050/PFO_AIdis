import glob
import numpy as np
import torch
import os
import cv2
import torchvision.transforms as transforms
from PIL import Image
from model.unet_model import UNet


def valid_epoch(net,device,test,pre_path):
    norm_mean = [0.485, 0.456, 0.406]
    norm_std = [0.229, 0.224, 0.225]
    transform = transforms.Compose([
        # transforms.Grayscale(1),
        # transforms.Resize(512),
        # transforms.CenterCrop(512),
        transforms.ToTensor(),
        # transforms.Normalize(norm_mean, norm_std),
    ])
    valid_loss, val_dice ,val_acc, val_recall, val_precision, val_IoU= 0.0, 0.0,0.0, 0.0,0.0,0.0
    net.eval()

    for test_path in test:
        # 保存结果地址
        save_path = test_path[test_path.find("image")+5:]
        save_res_path = pre_path + save_path
        contours_path = test_path.replace('image', 'contours')
        label_path = test_path.replace('image', 'label')
        if '_darker' in label_path or '_brighter' in label_path or '_salt' in label_path:
            index = label_path.rfind('_')
            label_path = label_path.replace(label_path[index:],'.jpg')
        # 读取图片
        image = cv2.resize(cv2.imread(test_path), (256, 256))
        img = Image.open(test_path)
        shape = (img._size[0], img._size[1])
        img = img.resize((256, 256))
        img = transform(img)
        # 转为灰度图
        # img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        # 转为batch为1，通道为1，大小为512*512的数组
        img = img.reshape(1, 3, img.shape[1], img.shape[2])
        # 转为tensor
        # img_tensor = torch.from_numpy(img)
        # 将tensor拷贝到device中，只用cpu就是拷贝到cpu中，用cuda就是拷贝到cuda中。
        img_tensor = img.to(device=device, dtype=torch.float32)
        # 预测
        pred = net(img_tensor)

        # 提取结果
        pred = np.array(pred.data.cpu()[0])[0]
        # visulize_spatial_attention(img_path=test_path, attention_mask=pred)        # 处理结果
        pred[pred >= 0.5] = 255
        pred[pred < 0.5] = 0
        pred1 = cv2.cvtColor(pred, cv2.COLOR_GRAY2BGR)
        contours = cv2.imread(contours_path)
        contours = cv2.resize(contours,(256, 256))
        upper2 = pred <= 255
        lower2 = pred >= 200
        contours_thresh = (np.multiply(upper2, lower2).astype(np.float32) * 255).astype(np.uint8)
        pred = pred.astype(np.uint8)
        label = cv2.cvtColor(cv2.resize(cv2.imread(label_path), (256, 256)), cv2.COLOR_BGR2GRAY)
        label[label >= 100] = 255
        label[label < 100] = 0
        dice, acc, recall, precision, IoU = Cal_Dice(label, pred)
        val_dice += dice
        val_acc += acc
        val_recall += recall
        val_precision += precision
        val_IoU += IoU
        # pred = cv2.resize(pred, shape, interpolation=cv2.INTER_LINEAR)
        # 保存图片
        # pred1[:, :, :][pred == 255] = [0, 0, 255]
        cv2.imwrite(save_res_path, pred)
        precontours, hierarchy = cv2.findContours(contours_thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(contours, precontours, -1, (0, 0, 255), 1)
        save_contours_path = save_res_path.replace('jpg', 'png')
        contours = cv2.resize(contours, shape, interpolation=cv2.INTER_LINEAR)
        cv2.imwrite(save_res_path, pred1)
        cv2.imwrite(save_contours_path, contours)
    ever_dice = val_dice / len(test)
    ever_acc = val_acc / len(test)
    ever_recall = val_recall / len(test)
    ever_precision = val_precision / len(test)
    ever_IoU = val_IoU / len(test)
    return ever_dice,ever_acc,ever_recall,ever_precision,ever_IoU


def Cal_Dice(label,pred):
    TN,FN,TP,FP,dice_label,dice_pred = 0,0,0,0,0,0
    smooth = 1
    for i in range(label.shape[0]):
        for j in range(label.shape[1]):
            if(label[i][j] == 0.0 and pred[i][j] == 0.0):
                TN +=1
            elif(label[i][j] == 255.0 and pred[i][j] == 0.0):
                FN += 1
            elif(label[i][j] == 255.0 and pred[i][j] == 255.0):
                TP +=1
            elif (label[i][j] == 0.0 and pred[i][j] == 255.0):
                FP += 1

    dice = (2*TP+smooth)/(FP+FN+2*TP+smooth)
    acc = (TP+TN+smooth)/(TP+TN+FP+FN+smooth)
    recall = (TP+smooth)/(TP+FN+smooth)
    precision = (TP+smooth)/(TP+FP+smooth)
    IoU = (TP+smooth)/(FN+FP+TP+smooth)
    return dice,acc,recall,precision,IoU


if __name__ == "__main__":
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # 加载网络，图片单通道，分类为1。
    net = UNet(n_channels=3, n_classes=1)
    # 将网络拷贝到deivce中
    net.to(device=device)
    # 加载模型参数
    net.load_state_dict(torch.load(r'.\data\06-23_08-03/test5/best_model5.pth', map_location=device))
    # 测试模式
    net.eval()
    test_path = r'./data\image'
    pre_path = test_path.replace('image', 'pre')
    test = glob.glob(os.path.join(test_path, '*.jpg'))
    dice, acc, recall, precision = valid_epoch(net, device, test, pre_path)
    print('dice:{}    acc:{}    recall:{}    precision:{}'.format(dice, acc, recall, precision))


