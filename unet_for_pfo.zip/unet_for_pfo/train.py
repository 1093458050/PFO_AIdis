#超声数据集
from utils.dataset import ISBI_Loader
from predict import valid_epoch
import torchvision.transforms as transforms
from model.unet_model import UNet
from torch import optim
import torch.nn as nn
from torch.utils.data import DataLoader
import os
import numpy as np
import glob
import time
from datetime import datetime
from tensorboardX import SummaryWriter
from sklearn.model_selection import KFold
from model.unet_model import *




os.environ["CUDA_DEVICES_ORDER"]="PCI_BUS_IS"# 按照PCI_BUS_ID顺序从0开始排列GPU设备

os.environ["CUDA_VISIBLE_DEVICES"] = "0,1" #设置当前使用的GPU设备仅为0号设备  设备名称为'/gpu:0'

def train_epoch(net,device,train_loader,criterion,optimizer):
    train_loss ,train_correct= 0.0,0.0
    net.train()
    for image, label in train_loader:
        optimizer.zero_grad()  # 梯度清零
        # 将数据拷贝到device中
        image = image.to(device, dtype=torch.float32)
        label = label.to(device, dtype=torch.float32)
        pred = net(image)
        # 计算loss
        loss = criterion(pred, label)
        loss.backward()
        optimizer.step()
        train_loss += loss.item()
    return train_loss,net

def data_process(few_imgs_path,large_imgs_path,max_imgs_path,mid_imgs_path,none_imgs_path,train_transform):
    few = ISBI_Loader(few_imgs_path,train_transform)
    large = ISBI_Loader(large_imgs_path,train_transform)
    max = ISBI_Loader(max_imgs_path,train_transform)
    mid = ISBI_Loader(mid_imgs_path,train_transform)
    none = ISBI_Loader(none_imgs_path,train_transform)
    return few


def data_set(kf,sub_imgs_path):
    sub_train, sub_test = [], []
    for sub_fold, (sub_train_idx, sub_val_idx) in enumerate(kf.split(np.arange(len(sub_imgs_path)))):
        sub_train.append(sub_train_idx)
        sub_test.append(sub_val_idx)
    return sub_train,sub_test

def data_append(test,train,imgs_path,sub_train,sub_test,index):
    for sub_train_index in sub_train[index]:
        train.append(imgs_path[sub_train_index])
    for sub_test_index in sub_test[index]:
        test.append(imgs_path[sub_test_index])
    return test,train


if __name__ == "__main__":
    # 定义Loss算法
    criterion = nn.BCEWithLogitsLoss()

    norm_mean = [0.485, 0.456, 0.406]
    norm_std = [0.229, 0.224, 0.225]
    train_transform = transforms.Compose([
        transforms.ToTensor(),
    ])

    # 指定训练集地址，开始训练
    epochs = 3
    milestones = [3,6,7,9]
    batch_size = 8
    n_splits = 10
    now_time = datetime.now()
    time_str = datetime.strftime(now_time, '%m-%d_%H-%M')
    data_path = r"./data/"
    imgs_path = glob.glob(os.path.join(data_path, 'class1/image/*.jpg'))
    large_imgs_path = glob.glob(os.path.join(data_path, 'class3/image/*.jpg'))
    max_imgs_path = glob.glob(os.path.join(data_path, 'class4/image/*.jpg'))
    mid_imgs_path = glob.glob(os.path.join(data_path, 'class2/image/*.jpg'))
    none_imgs_path = glob.glob(os.path.join(data_path, 'class0/image/*.jpg'))
    isbi_dataset  = data_process(few_imgs_path,large_imgs_path,max_imgs_path,mid_imgs_path,none_imgs_path,train_transform)
    kf = KFold(n_splits=n_splits)
    few_train,few_test = data_set(kf,few_imgs_path)
    large_train,large_test = data_set(kf,large_imgs_path)
    max_train,max_test = data_set(kf,max_imgs_path)
    mid_train, mid_test = data_set(kf,mid_imgs_path)
    none_train, none_test = data_set(kf,none_imgs_path)
    testDice,testAcc,testRecall,testPrecision,testIoU = [],[],[],[],[]
    for index in range(len(few_train)):
        best_loss = float('inf')
        start_time = time.time()
        test,train = [],[]
        total_acc = 0
        lr = 0.01
        test,train = data_append(test, train, few_imgs_path, few_train, few_test, index)
        test,train = data_append(test, train, large_imgs_path, large_train, large_test, index)
        test,train = data_append(test, train, max_imgs_path, max_train, max_test, index)
        test,train = data_append(test, train, mid_imgs_path, mid_train, mid_test, index)
        test,train = data_append(test, train, none_imgs_path, none_train, none_test, index)
        isbi_dataset.imgs_path = train
        train_loader = DataLoader(dataset=isbi_dataset, batch_size=batch_size, shuffle=True)
        net = UNet(n_channels=3, n_classes=1)
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        if torch.cuda.device_count() > 1:
            net = nn.DataParallel(net, device_ids=[0, 1])
        net.to(device)
        optimizer = optim.SGD(net.parameters(), lr=lr, momentum=0.9, weight_decay=1e-4)  # 优化器
        scheduler = optim.lr_scheduler.MultiStepLR(optimizer, gamma=0.1, milestones=milestones)
        writer = SummaryWriter(comment='_index_'+str(index)+'_lr_'+str(lr))
        pre_path = 'data/' + time_str + '/test{}/'.format(index + 1)
        isExists = os.path.exists(pre_path)
        if not isExists:
            os.makedirs(pre_path)
        fw = open(r'data/' + time_str + '/bs_' + str(batch_size) + '.txt', 'w')
        for epoch in range(epochs):
            train_loss,net = train_epoch(net, device, train_loader, criterion, optimizer)
            train_loss = train_loss / len(train)
            if (train_loss < best_loss or train_loss == best_loss):
                best_loss = train_loss
                torch.save(net.state_dict(), pre_path+'best_model{}.pth'.format(index+1))

            print("Fold[{}/{}] : epoch[{}/{}] AVG Training Loss:{:.3f} AVG  LR:{} "
                  .format(index+1,n_splits,epoch+1,epochs, train_loss, optimizer.param_groups[0]["lr"]))
            fw.write("Fold[{}/{}] : epoch[{}/{}] AVG Training Loss:{:.3f} AVG  LR:{} "
                  .format(index+1,n_splits,epoch+1,epochs, train_loss, optimizer.param_groups[0]["lr"]))
            scheduler.step()
            writer.add_scalar('data/trainloss', train_loss, epoch)

        test_dice,test_acc,test_recall,test_precision,test_IoU= valid_epoch(net, device, test,pre_path)
        testDice.append(test_dice)
        testAcc.append(test_acc)
        testRecall.append(test_recall)
        testPrecision.append(test_precision)
        testIoU.append(test_IoU)
        end_time = time.time()
        print('Fold{}---：dice >> {}    test_acc >> {}     test_IoU >> {}'.format(index+1,test_dice,test_acc,test_IoU))
        print('time:{:.3f}'.format(end_time - start_time))
        fw.write('Fold{}---：dice >> {}    test_acc >> {}     test_IoU >> {}'.format(index+1,test_dice,test_acc,test_IoU))
        fw.write('time:{:.3f}'.format(end_time - start_time))
        writer.close()
    fw.write('testDice:{}'.format(testDice))
    fw.write('testAcc:{}'.format(testAcc))
    fw.write('testRecall:{}'.format(testRecall))
    fw.write('testPrecision:{}'.format(testPrecision))
    fw.write('testIoU:{}'.format(testIoU))
    mean_dice,mean_acc,mean_recall,mean_precision,mean_IoU,best_dice= 0.0,0.0,0.0,0.0,0.0,0.0
    best_fold = 0
    for i in range(len(testDice)):
        mean_dice += testDice[i]
        mean_acc += testAcc[i]
        mean_recall += testRecall[i]
        mean_precision += testPrecision[i]
        mean_IoU += testIoU[i]
        if best_dice < testDice[i]:
            best_dice = testDice[i]
            best_fold = i+1
    print('AVG_Dice：{}  AVG_Acc：{}  AVG_recall：{} '.format(mean_dice/len(testDice),
                                             mean_acc/len(testDice),mean_recall/len(testDice)))
    print('AVG_Precision：{}    AVG_IoU：{}'.format(mean_precision/len(testDice),mean_IoU/len(testDice)))
    print(" done ~~~~ , best dice: {} in :{} epochs. ".format(best_dice, best_fold))
    fw.write('AVG_Dice：{}  AVG_Acc：{}  AVG_recall：{} '.format(mean_dice/len(testDice),
                                             mean_acc/len(testDice),mean_recall/len(testDice)))
    fw.write('AVG_Precision：{}    AVG_IoU：{}'.format(mean_precision/len(testDice),mean_IoU/len(testDice)))
    fw.write(" done ~~~~ , best dice: {} in :{} epochs. ".format(best_dice, best_fold))
fw.close()