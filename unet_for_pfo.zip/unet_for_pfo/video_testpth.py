import glob
import numpy as np
import torch
import os
import torch.nn as nn
import cv2
import torchvision.transforms as transforms
from PIL import Image
from unet2 import NestedUNet
from model.unet_model import UNet
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"

def Cal_Dice(label, pred):
    FN, TP, FP = 0, 0, 0
    for i in range(label.shape[0]):
        for j in range(label.shape[1]):
            # if(label[i][j] == 0 and pred[i][j] == 0):
            #     TN +=1
            if (label[i][j] == 255):
                FN += 1
            if (pred[i][j] == 255):
                FP += 1
            if (label[i][j] == 255 and pred[i][j] == 255):
                TP += 1
    acc = 2 * TP / (FP + FN)
    # loss = (FP+FN)/(TP+FP+FN)
    return acc


if __name__ == "__main__":
    norm_mean = [0.485, 0.456, 0.406]
    norm_std = [0.229, 0.224, 0.225]
    transform = transforms.Compose([
        # transforms.Grayscale(1),
        # transforms.Resize(512),
        # transforms.CenterCrop(512),
        transforms.ToTensor(),
        # transforms.Normalize(norm_mean, norm_std),
    ])
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # 加载网络，图片单通道，分类为1。
    # net = NestedUNet(in_ch=3, out_ch=1)
    net = UNet(3, 1)
    if torch.cuda.device_count() > 1:
        net = nn.DataParallel(net, device_ids=[0, 1])
    # 将网络拷贝到deivce中
    net.to(device=device)
    # 加载模型参数
    net.load_state_dict(torch.load(r'data/06-16_17-00unet_bs=4\test6/best_model6.pth', map_location=device))
    # 测试模式
    net.eval()
    # 读取所有图片路径
    data_path = r'E:\gmj\dicom\newzhen\full'
    dir_list = os.listdir(data_path)
    for dbtype in dir_list[::]:
        list = os.listdir(data_path + '\\' + dbtype)
        print('路径：', list)
        for type in list[::]:
            path = data_path + '\\' + dbtype + '\\' + type
            tests_path = glob.glob(data_path + '\\' + dbtype + '\\' + type + '/*.png')
            net.eval()
            for test_path in tests_path:
                # 保存结果地址
                save_pred_path = test_path.replace('full', 'label')
                save_cou_path = test_path.replace('full', 'contours')
                save_mask_path = test_path.replace('full', 'seg')
                # 读取图片
                img = Image.open(test_path)
                shape = (img._size[0], img._size[1])
                img = img.resize((256, 256))
                img = transform(img)
                # 转为batch为1，通道为1，大小为512*512的数组
                img = img.reshape(1, 3, img.shape[1], img.shape[2])
                # 将tensor拷贝到device中，只用cpu就是拷贝到cpu中，用cuda就是拷贝到cuda中。
                img_tensor = img.to(device=device, dtype=torch.float32)
                # 预测
                pred = net(img_tensor)
                # 提取结果
                pred = np.array(pred.data.cpu()[0])[0]
                # 处理结果
                pred[pred >= 0.5] = 255
                pred[pred < 0.5] = 0
                upper2 = pred <= 255
                lower2 = pred >= 200
                image = cv2.resize(cv2.imread(test_path), (256, 256))
                # resize_path = test_path.replace('full', 'resize')
                # cv2.imwrite(resize_path, image)
                contours_thresh = (np.multiply(upper2, lower2).astype(np.float32) * 255).astype(np.uint8)
                pred = pred.astype(np.uint8)
                masked = cv2.add(image, np.zeros(np.shape(image), dtype=np.uint8), mask=pred)
                # masked = cv2.resize(masked, shape, interpolation=cv2.INTER_LINEAR)
                # masked = cv2.resize(masked, shape, interpolation=cv2.INTER_LINEAR)
                masked = cv2.resize(masked, (800,600), interpolation=cv2.INTER_LINEAR)
                cv2.imwrite(save_mask_path, masked)
                # pred = cv2.resize(pred, shape, interpolation=cv2.INTER_LINEAR)
                # 保存图片
                pred1 = cv2.cvtColor(pred, cv2.COLOR_GRAY2BGR)
                pred1[:,:,:][pred == 255] = [255, 0, 255]
                cv2.imwrite(save_pred_path, pred1)
                result = cv2.addWeighted(image, 1, pred1, 0.2, 0)
                addweighted_path = test_path.replace('full', 'add_weighted')
                precontours, hierarchy = cv2.findContours(contours_thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                contours = cv2.drawContours(image, precontours, -1, (0, 0, 255), 1)
                # contours = cv2.resize(contours, shape, interpolation=cv2.INTER_LINEAR)
                cv2.imwrite(addweighted_path, result)
                cv2.imwrite(save_cou_path, contours)
