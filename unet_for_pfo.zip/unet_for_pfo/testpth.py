import glob
import numpy as np
import torch
import os
import cv2
import torchvision.transforms as transforms
from PIL import Image
from model.unet_model import UNet

def Cal_Dice(label, pred):
    FN, TP, FP = 0, 0, 0
    for i in range(label.shape[0]):
        for j in range(label.shape[1]):
            # if(label[i][j] == 0 and pred[i][j] == 0):
            #     TN +=1
            if (label[i][j] == 255):
                FN += 1
            if (pred[i][j] == 255):
                FP += 1
            if (label[i][j] == 255 and pred[i][j] == 255):
                TP += 1
    acc = 2 * TP / (FP + FN)
    # loss = (FP+FN)/(TP+FP+FN)
    return acc


if __name__ == "__main__":
    norm_mean = [0.485, 0.456, 0.406]
    norm_std = [0.229, 0.224, 0.225]
    transform = transforms.Compose([
        # transforms.Grayscale(1),
        # transforms.Resize(512),
        # transforms.CenterCrop(512),
        transforms.ToTensor(),
        transforms.Normalize(norm_mean, norm_std),
    ])
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net = UNet(n_channels=3, n_classes=1)
    net.to(device=device)
    net.load_state_dict(torch.load('./data/06-30_11-58/test2/best_model2.pth', map_location=device))
    net.eval()
    tests_path = glob.glob('data/test/image/*.jpg')
    valid_loss, val_correct = 0.0, 0.0
    net.eval()
    for test_path in tests_path:
        contours_path = test_path.replace('image', 'contours')
        label_path = test_path.replace('image', 'label')
        save_pred_path = test_path.replace('jpg','png')
        save_cou_path = test_path.replace('image','image/contours')
        img = Image.open(test_path)
        img = img.resize((256, 256))
        img = transform(img)
        img = img.reshape(1, 3, img.shape[1], img.shape[2])
        img_tensor = img.to(device=device, dtype=torch.float32)
        pred = net(img_tensor)
        pred = np.array(pred.data.cpu()[0])[0]
        pred[pred >= 0.5] = 255
        pred[pred < 0.5] = 0
        cv2.imwrite(save_pred_path, pred)
        label = cv2.cvtColor(cv2.resize(cv2.imread(label_path), (256, 256)), cv2.COLOR_BGR2GRAY)
        contours = cv2.imread(contours_path)
        contours = cv2.resize(contours, (256, 256))
        upper2 = pred <= 255
        lower2 = pred >= 200
        contours_thresh = (np.multiply(upper2, lower2).astype(np.float32) * 255).astype(np.uint8)
        try:
            precontours, hierarchy = cv2.findContours(contours_thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(contours, precontours, -1, (0, 0, 255), 1)
            cv2.imwrite(save_cou_path, contours)
            acc = Cal_Dice(label, pred)
            val_correct += acc
        except:
            print(contours_path)
    ever_correct = val_correct / len(tests_path)
    print('acc：',ever_correct)


